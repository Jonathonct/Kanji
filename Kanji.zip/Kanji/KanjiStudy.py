import KanjiFind
import os

def create(K, n, JLPT):
    i = 0
    while(1):
        if i == 0:
            user_in = input('Would you like to study kanji or kotoba (vocab words)?\n')
            if(user_in.lower() != 'kanji' and user_in.lower() != 'kotoba'):
                print('Please enter "kanji" for kanji or "kotoba" to study vocabulary')
                continue
            i+= 1
            K = user_in.lower()
        if i == 1:
            user_in = input('How many {0} would you like to see?\n'.format(K))
            if user_in.isdigit() == True:
                if(int(user_in) > 50 or int(user_in) < 1):
                    print('Please choose a value between 1 and 50')
                    continue
            else:
                print('Please choose a value between 1 and 50')
                continue
            n = int(user_in)
            i += 1
        if i == 2:
            user_in = input('Finally, what JLPT level would you like to study from? (Type help for more info)\n')
            if user_in.isdigit() == True:
                if (int(user_in) < 1 or int(user_in) > 5):
                    print('JLPT level 1 is the hardest, and JLPT level 5 is the easiest.')
                    continue
            else:
                print('JLPT level 1 is the hardest, and JLPT level 5 is the easiest.')
                continue 
            JLPT = int(user_in)
        user_in= input('Shall we create {0} {1} from JLPT level {2}?\n'.format(n, K, JLPT))
        if(user_in != ''):
            if(user_in[0].lower() != 'y'):
                i = 0
                continue
            break
        else:
            i = 3
            continue
    return K, n, JLPT

def reset(k, K, n, JLPT, mode):
    i = 0
    while(1):
        if(i == 0):
            user_in= input('Would you like to try again with the same set and mode? (yes or no)\n')
            if(user_in == ''): continue
            if(user_in[0].lower() == 'n'): #Quit, change mode, set or both
                user_in= input('Would you like to exit the program?\n')
                if(user_in == ''): continue
                if(user_in[0].lower() == 'y'): os._exit(1)
                else:
                    i+= 1
                    continue
            elif(user_in[0].lower() == 'y'): #Try again with same mode/ set
                user_in= input('Try again with the exact same mode and set?\n')
                if(user_in == ''): continue
                if(user_in[0].lower() == 'y'):
                    main(k, K, n, JLPT, mode, False, False)
                    break
                else: continue
            else: continue
        if(i == 1):
            user_in= input('Would you like to change the set?\n')
            if(user_in == ''): continue
            if(user_in[0].lower() == 'n'):
                i+= 1
                continue
            elif(user_in[0].lower() == 'y'): #Create new mode and set
                user_in= input('Create a new set and mode?\n')
                if(user_in == ''): continue
                if(user_in[0].lower() == 'y'):
                    main('', '', 0, 0, '', True, True)
                    break
            else:
                i = 0
                continue
        if(i==2):
            user_in= input('Would you like to change the mode?\n')
            if(user_in == ''): continue
            if(user_in[0].lower() == 'y'):
                user_in= input('Try again with the same set but new mode?\n')
                if(user_in == ''): continue
                if(user_in[0].lower() == 'y'):
                    main(k, K, n, JLPT, '', True, False)
                    break
            elif(user_in[0].lower() == 'n'):
                print("If you don't want to change anything, then...")
                i=0
            else: continue

def get_mode(K):
    while(1):
        mode= ''
        if K == 'kanji':
            print('We can study just the kanji, just the readings, both, or the English meaning.')
            print('Type "meaning," "kanji," "reading," or "both" to select mode.')
            mode += 'k' #indicates kanji mode
        else:
            print('We can study the kotoba, just the reading or both, or the English meaning.')
            print('Type "meaning," "kotoba," "reading," or "both" to select mode.')
            mode += 'K' #indicates kotoba mode
        user_in = input('Which study mode would you like to try?\n')
        if(user_in == ''): continue
        if (user_in[0].lower() != 'b' and user_in[0].lower() != 'r' and user_in[0].lower() != 'k' and user_in[0].lower() != 'm'): continue
        elif user_in[0].lower() == 'b': mode += 'both'
        elif K == 'kanji' and user_in[0].lower() == 'k': mode += 'kanji'
        elif K == 'kotoba' and user_in[0].lower() == 'k': mode += 'kotoba'
        elif user_in[0].lower() == 'r': mode += 'reading'
        elif user_in[0].lower() == 'm': mode += 'meaning'
        user_in = input('Shall we study the {0} by this mode: {1}?\n'.format(K, mode[1:]))
        if(user_in == ''): continue
        if (user_in[0].lower() != 'y'): continue
        break
    return mode

def study(k, mode, n):
    i=0
    if(mode[0] == 'k'): #Study kanji
        for i in range(n):
            if(mode[1:] == 'kanji'):
                ans= KanjiFind.disp_Kanji(k[i], 1)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kanji(k[i], 0)
            elif(mode[1:] == 'reading'):
                ans1, ans2= KanjiFind.disp_Kanji(k[i], 2)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kanji(k[i], 0)
            elif(mode[1:] == 'both'):
                ans1, ans2, ans3= KanjiFind.disp_Kanji(k[i], 3)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kanji(k[i], 0)
            elif(mode[1:] == 'meaning'):
                ans = KanjiFind.disp_Kanji(k[i], 4)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kanji(k[i], 0)
            user_in = input("Type 'quit' to change the list or mode\n")
            if(user_in == ''): continue
            if(user_in[0].lower() == 'q'): break
                
    elif(mode[0] == 'K'): #Study kotoba
        for i in range(n):
            if(mode[1:] == 'kotoba'):
                ans= KanjiFind.disp_Kotoba(k[i], 1)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kotoba(k[i], 0)
            elif(mode[1:] == 'reading'):
                ans= KanjiFind.disp_Kotoba(k[i], 2)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kotoba(k[i], 0)
            elif(mode[1:] == 'both'):
                ans1, ans2= KanjiFind.disp_Kotoba(k[i], 3)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kotoba(k[i], 0)
            elif(mode[1:] == 'meaning'):
                ans = KanjiFind.disp_Kotoba(k[i], 4)
                print('\nThe correct answer is...')
                KanjiFind.disp_Kotoba(k[i], 0)
            user_in = input("Type 'quit' to change the list or mode\n")
            if(user_in == ''): continue
            if(user_in[0].lower() == 'q'): break
    return

#Main function creates n kanji/kotoba from JLPT level and calls itself if reiteration is desired
#new_k means new kanji/kotoba need to be acquired, new_mode means new mode needs to be acquired
#Changing from kanji to kotoba will cause a mode switch
def main(k, K, n, JLPT, mode, new_mode, new_k):
    K_old = K
    if(new_k == True):
        K, n, JLPT= create(K, n, JLPT)
    if(new_mode == True or K_old != K): mode = get_mode(K)
    if(new_k == True): k= KanjiFind.main(K, n, JLPT)
    print('\n' * 50) #Portable clear screen
    study(k, mode, n)
    reset(k, K, n, JLPT, mode)
    print('\n' * 50) #Portable clear screen

#Run first iteration...
main('', '', 0, 0, '', True, True)
