#This file defines the kanji and kotaba classes which programs will use
#The kotoba class contains a word made of one or more kanji characters, 
#the reading in hiragana, the meaning in English and JLPT level
#Note that the default Windows terminal does not support Japanese characters

class kotoba:
  def __init__(self, word, yomikata, imi, JLPT):
    self.word= word
    self.yomikata= yomikata
    self.imi= imi
    self.JLPT= JLPT
    self.type= 'none'

#The kanji class contains a kanji character, its Chinese and Japanese
#reading(s), its meaning in English and JLPT level 
class kanji:
  def __init__(self, character, onyomi, kunyomi, imi, JLPT):
    self.character= character
    self.onyomi= onyomi
    self.kunyomi= kunyomi
    self.imi= imi
    self.JLPT= JLPT

#The progdata class is used to keep track of open files and such
class progdata:
  def __init__(self):
    self.noline= [1232, 367, 367, 166, 79, 3272, 1835, 1835, 634, 669] #Records number of lines in files[0-4] are kanji files, ofiles[5-9] are kotoba files
	
#The kana class is used to identify a string as katakana or hiragana
class kana:
    hiragana=['あいうえおさしすせそたちつてとかきくけこはひふへほまみむめもなにぬねのらりるれろやゆよをんわがぎぐげござじずぜぞだぢづでどぱぴぷぺぽばびぶべぼゃゅょっ']
    katakana=["アイウエオサシスセソカキクケコタチツテトハヒフヘホマミムメモナニヌネノラリルレロヤヨユワヲンガギグゲゴザヂズゼゾダジデドパピプペポバビブベボヅヂャュュョィォァェゥッ"]