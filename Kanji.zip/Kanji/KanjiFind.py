#This file takes in a request to find a kanji or compound word from 
#a particular JLPT level (or all) from a selection of files
import KanjiType
import linecache
from random import randint

#Acquire a kanji from file. -1 is random kanji, -2 is random kotoba
def get_ln(JLPT, K, prog):
   if (JLPT > 4 and JLPT < 10): #Kotoba
       Line= linecache.getline('VocabN{0}.txt'.format(str(JLPT-4)), get_rand(1, prog.noline[JLPT]))
       read_ln(2, K, Line)
       return K
   elif (JLPT>=0 and JLPT<5): #Kanji
       Line= linecache.getline('KanjiN{0}.txt'.format(str(JLPT+1)), get_rand(1, prog.noline[JLPT]))
       read_ln(1, K, Line)
       return K
   return

#Reads the line acquired from file into a manner usable
def read_ln(Type, K, Line):
   i=0 #Used to navigate the string
   kan= True
   hir= False
   kat= False
   #If kan = true, reading kanji. If hir= true, reading hiragana. If kat= true, reading katakana. If none are true, reading English
   if Type==1: #Kanji
      for letter in Line:
         nxtchr= Line[i]
         if(nxtchr == '\n'): break
         i+= 1
         if nxtchr != '-': #Ignore random dashes
            if ((kan == True or hir == True or kat == True) and nxtchr != '.' and nxtchr != '-' and nxtchr != '/'):
               check = def_chr(nxtchr)
            #If we are changing character types, change mode
            #This algorithm knows that kanji always come first, followed by katakana, then hiragana
            if(check != 'w'):
               if (kan == True and check == 'k'):
                  kan = False
                  kat = True
               elif (kan == True and check == 'h'):
                  hir = True
                  kan = False
               elif (kat == True and check == 'h'):
                  hir = True
                  kat = False
               elif (hir == True and check == 'n'): hir = False
               elif (kat == True and check == 'n'): kat = False
               elif (kan == True and check == 'n' and K.character != ''): kan = False
            #Write to data structure
            if kan == True:
               K.character+= nxtchr
            elif hir == True:
               K.kunyomi+= nxtchr
            elif kat == True:
               K.onyomi+= nxtchr
            elif (kan == False and kat == False and hir == False):
               if K.imi != '' or check != 'w':
                  K.imi+= nxtchr

      
   elif Type==2: #Kotoba
      #For vocabulary words, there are three different types
      first = True
      for letter in Line:
         nxtchr= Line[i]
         if(nxtchr == '\n'): break
         i+=1
         if(nxtchr != '/' and nxtchr != '-' and nxtchr != '.'): #Defined chars shouldn't change mode
            check = def_chr(nxtchr)
            if(kan == True and check == 'w'): #Swapping to yomikata
               kan = False
               hir = True
               continue
            elif ((kan == True or kat == True or hir == True) and check == 'w'): continue
            #It is crucial to identify the type of word (Kanji, Katakana, Hiragana)
            if (first == True and check == 'h'): #Case where first character is hiragana
               first = False
               kan = False
               hir = True
               K.type = 'hir'
            elif (first == True and check == 'k'): #Case where the first character is katakana
               first = False
               kan = False
               kat = True
               K.type = 'kat'
            elif (first == True): #Case where the first character is a kanji
               first = False
               K.type = 'kan'
         if (kan != True and check == 'n'): #Case where we are switching to imi
            kat = False
            kan = False
            hir = False
         if(kan == True):
            K.word+= nxtchr
         elif(kat == True):
            K.word+= nxtchr
         elif(K.type == 'hir' and hir == True):
            K.word+= nxtchr
         elif(K.type == 'kan' and hir == True):
            K.yomikata += nxtchr
         else:
            K.imi+= nxtchr
   #Return completed kanji or kotoba structure
   return K

#Define a character as hiragana or katakana or neither
def def_chr(char):
   if(char == ' ' or char == '   ' or char == '	'):
      return 'w'
   i = 0
   hir= KanjiType.kana.hiragana[0]
   for i in range(75):
      if hir[i] == char:
         return 'h'
      i+= 1
   i = 0
   kat= KanjiType.kana.katakana[0]
   for i in range(82):
      if kat[i] == char:
         return 'k'
      i+= 1
   return 'n'
   
         
#Acquire a pseudo-random number  
def get_rand(strt, rng):
    num = randint(strt, rng)
    return num

#Display a kanji element's data to screen
def disp_Kanji(Kanji, mode):
    if(mode == 4):
       print('Character = {0}'.format(Kanji.character))
       print('Kunyomi = {0}'.format(Kanji.kunyomi))
       print('Onyomi = {0}'.format(Kanji.onyomi))
       ans = input('Meaning = ')
       return ans
    print('Meaning = {0}'.format(Kanji.imi))
    if(mode == 1):
       print('Kunyomi = {0}'.format(Kanji.kunyomi))
       print('Onyomi = {0}'.format(Kanji.onyomi))
       ans= input('Character = ')
       return ans
    elif(mode == 2):
       print('Character = {0}'.format(Kanji.character))
       ans1= input('Kunyomi = ')
       ans2= input('Onyomi = ')
       return ans1, ans2
    elif(mode == 3):
       ans1= input('Character = ')
       ans2= input('Kunyomi = ')
       ans3= input('Onyomi = ')
       return ans1, ans2, ans3
    else:
       print('Character = {0}'.format(Kanji.character))
       print('Kunyomi = {0}'.format(Kanji.kunyomi))
       print('Onyomi = {0}'.format(Kanji.onyomi))

#Display a kotoba element's data to screen
#Filter if given, 0 is no filter
def disp_Kotoba(Kotoba, mode):
   if(mode == 4):
      print('Word = {0}'.format(Kotoba.word))
      print('Reading = {0}'.format(Kotoba.yomikata))
      ans= input('Meaning = ')
      return ans
   print('Meaning = {0}'.format(Kotoba.imi))
   if(mode == 1):
      print('Reading = {0}'.format(Kotoba.yomikata))
      ans= input('Word = ')
      return ans
   elif(mode == 2):
      print('Word = {0}'.format(Kotoba.word))
      ans= input('Reading = ')
      return ans
   elif(mode == 3):
      ans1= input('Word = ')
      ans2= input('Reading = ')
      return ans1, ans2
   else:
      print('Word = {0}'.format(Kotoba.word))
      print('Reading = {0}'.format(Kotoba.yomikata))

#Begin main function
#Find n types of K structure: Kanji or Kotoba in JLPT level specified
#Note that 0 corresponds to all levels
def main(Ktype, n, JLPT):
   prog = KanjiType.progdata() #Used to follow/record accessed information
   i = 0
   k = []
   for i in range(n):
      if Ktype == 'kanji': #Create n kanji
         Kanji = KanjiType.kanji('', '', '', '', JLPT)
         Kanji = get_ln(JLPT-1, Kanji, prog)
         k.append(Kanji)
      else: #Create n kotoba
         Kotoba = KanjiType.kotoba('', '', '', JLPT)
         Kotoba = get_ln(JLPT+4, Kotoba, prog)
         k.append(Kotoba)
      i+= 1
   return k

